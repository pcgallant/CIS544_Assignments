#pragma once
class Sums
{
public:
	Sums();
	bool SetEndInt(int n);
	int SumAllInt(int n);
private:
	int endInt;
};

